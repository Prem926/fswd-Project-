let quizzes = [
    {
        "question": " Which one of the following node is considered the top of the stack if the stack is implemented using the linked list?",
        "optionA": "First node",
        "optionB": "Second node",
        "optionC": "Last node",
        "optionD": "None of the above",
        "multipleAnswers": "false",
        "answerA": "true",
        "answerB": "false",
        "answerC": "false",
        "answerD": "false",
        "category": "dsa",
        "id": 60
    },
    {
        "question": " Which one of the following node is considered the top of the stack if the stack is implemented using the linked list?",
        "optionA": "First node",
        "optionB": "Second node",
        "optionC": "Last node",
        "optionD": "None of the above",
        "multipleAnswers": "false",
        "answerA": "true",
        "answerB": "false",
        "answerC": "false",
        "answerD": "false",
        "category": "dsa",
        "id": 60
    },
    {
        "question": " Which one of the following node is considered the top of the stack if the stack is implemented using the linked list?",
        "optionA": "First node",
        "optionB": "Second node",
        "optionC": "Last node",
        "optionD": "None of the above",
        "multipleAnswers": "false",
        "answerA": "true",
        "answerB": "false",
        "answerC": "false",
        "answerD": "false",
        "category": "dsa",
        "id": 60
    }
]